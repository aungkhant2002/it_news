<?php


namespace App;


class Base
{

    public static $name = "IT NEWS";
    public static $logo = "images/logos/logo.PNG";
    public static $description = "အိုင်တီ သတင်း အချက်အလက်များကို အချိန်နှင့်တပြေးညီ တင်ပြပေးမယ့် ဝက်(ဘ်)ဆိုဒ် တစ်ခု ဖြစ်ပါတယ်။";

}
