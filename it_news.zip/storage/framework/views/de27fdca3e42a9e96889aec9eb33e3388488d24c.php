<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
    <div class="d-flex justify-content-between align-items-center py-2 mt-3 nav-brand">
        <div class="d-flex align-items-center">
            <img src="<?php echo e(asset(\App\Base::$logo)); ?>" class="w-50" alt="">
        </div>
        <button class="hide-sidebar-btn btn btn-light d-block d-lg-none">
            <i class="feather-x text-primary" style="font-size: 2em;"></i>
        </button>
    </div>
    <div class="nav-menu">
        <ul>
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-home','link' => ''.e(route('home')).'','name' => 'Home']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'Item Management']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-plus-circle','name' => 'Add Item']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-list','name' => 'Item Lists','counter' => '15']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'Article Manager']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-layers','name' => 'Category Manager','link' => ''.e(route('category.index')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-plus-circle','name' => 'Create Article','link' => ''.e(route('article.create')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-list','name' => 'Article Lists','link' => ''.e(route('article.index')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'User Profile']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Your Profile','class' => 'feather-user','link' => ''.e(route('profile')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-message-square','link' => ''.e(route('profile.edit.name.email')).'','name' => 'Update Name & Email']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-refresh-cw','link' => ''.e(route('profile.edit.password')).'','name' => 'Change Password']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['class' => 'feather-image','link' => ''.e(route('profile.edit.photo')).'','name' => 'Update Photo']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <li class="menu-item">
                <a href="<?php echo e(route('logout')); ?>" class="btn btn-outline-primary w-100" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH D:\My Codes\my_projects\it_news\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>