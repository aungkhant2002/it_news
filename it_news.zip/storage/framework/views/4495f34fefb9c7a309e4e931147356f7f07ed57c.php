<?php $__env->startSection("title"); ?> About <?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="p-2">
        <h1>This is About Page</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("blog.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Codes\my_projects\it_news\resources\views/blog/about.blade.php ENDPATH**/ ?>