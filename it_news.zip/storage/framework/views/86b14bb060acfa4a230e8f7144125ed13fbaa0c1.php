<?php $__env->startSection("title"); ?> Edit Photo <?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active" aria-current="page">Upload Profile Photo</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="row">
        <div class="col-12 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <img src="<?php echo e(isset(Auth::user()->photo) ? asset("storage/profile/".Auth::user()->photo) : asset("dashboard/img/default-user-img.jpg")); ?>" class="w-50 d-block mx-auto rounded-circle my-3" alt="">
                    <form action="<?php echo e(route("profile.change.photo")); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-between align-items-end">
                            <div class="form-group mb-0 mr-2">
                                <label for="photo">
                                    <i class="feather-image"></i>
                                    Select New Photo
                                </label>
                                <input type="file" name="photo" id="photo" class="form-control mr-2 p-1">
                                <?php $__errorArgs = ["photo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="feather-upload"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Codes\my_projects\it_news\resources\views/user-profile/edit-photo.blade.php ENDPATH**/ ?>