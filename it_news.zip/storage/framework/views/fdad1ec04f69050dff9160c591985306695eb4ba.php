<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH D:\My Codes\my_projects\it_news\resources\views/components/menu-title.blade.php ENDPATH**/ ?>