<li class="menu-spacer"></li>
<?php /**PATH D:\My Codes\my_projects\it_news\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>