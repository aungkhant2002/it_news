<li class="menu-item">
    <a href="<?php echo e($link); ?>" class="menu-item-link <?php echo e(request()->url() === $link ? 'active' : ''); ?>">
        <span>
            <i class="<?php echo e($class); ?>"></i>
            <?php echo e($name); ?>

        </span>
        <?php if($counter >= 0): ?>
            <span class="badge badge-pill bg-white shadow-sm text-primary"><?php echo e($counter); ?></span>
        <?php endif; ?>
    </a>
</li>
<?php /**PATH D:\My Codes\my_projects\it_news\resources\views/components/menu-item.blade.php ENDPATH**/ ?>