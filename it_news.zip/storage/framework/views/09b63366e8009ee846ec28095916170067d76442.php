<?php $__env->startSection("title"); ?> <?php echo e($article->title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection("head"); ?>

    <style>
        .description {
            white-space: pre-line;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('article.index')); ?>">Article Lists</a></li>
        <li class="breadcrumb-item active" aria-current="page">Article Detail</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="row">
        <div class="col-12 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="font-weight-bold"><?php echo e($article->title); ?></h4>
                    <div class="">
                        <div class="mt-2 mb-4">
                            <span class="mr-3 text-primary"><i class="feather-layers mr-1"></i><?php echo e($article->category->title); ?></span>
                            <span class="mr-3 text-primary"><i class="feather-user mr-1"></i><?php echo e($article->user->name); ?></span>
                            <small class="mr-3 text-primary">
                                <i class="feather-calendar mr-1"></i>
                                <?php echo e($article->created_at->format('d-m-Y')); ?>

                            </small>
                            <small class="mr-3 text-primary">
                                <i class="feather-clock mr-1"></i>
                                <?php echo e($article->created_at->format('h:i A')); ?>

                            </small>
                        </div>
                    </div>
                    <p class="text-black-50 description"><?php echo e($article->description); ?></p>
                    <hr>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="">
                            <a href="<?php echo e(route('article.edit', $article->id)); ?>" class="btn btn-outline-warning">Edit</a>
                            <a href="<?php echo e(route('article.index')); ?>" class="btn btn-outline-dark">All Articles</a>
                        </div>
                        <p><?php echo e($article->created_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Codes\my_projects\it_news\resources\views/article/show.blade.php ENDPATH**/ ?>