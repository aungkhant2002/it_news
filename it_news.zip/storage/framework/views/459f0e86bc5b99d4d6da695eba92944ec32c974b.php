<?php $__env->startSection("content"); ?>
   <div class="">
       <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

           <div class="border-bottom mb-4 pb-4 article-preview">
               <div class="p-0 p-md-3">
                   <a class="fw-bold h4 d-block text-decoration-none"
                      href="<?php echo e(route("detail", $article->id)); ?>">
                       <?php echo e($article->title); ?>

                   </a>

                   <div class="small post-category mb-3">
                       <a href="<?php echo e(route("baseOnCategory", $article->category->id)); ?>" rel="category tag"><?php echo e($article->category->title); ?></a>
                   </div>

                   <div class="text-black-50 the-excerpt">
                       <p><?php echo e($article->description); ?></p>
                   </div>

                   <div class="d-flex justify-content-between align-items-center see-more-group">
                       <div class="d-flex align-items-center">
                           <?php if($article->user->photo): ?>
                               <img alt="" src="<?php echo e(asset("storage/profile/".$article->user->photo)); ?>"
                                    class="avatar avatar-50 photo rounded-circle" height="50" width="50"
                                    loading="lazy">
                           <?php else: ?>
                               <img alt="" src="<?php echo e(asset("dashboard/img/default-user-img.jpg")); ?>"
                                    class="avatar avatar-50 photo rounded-circle" height="50" width="50"
                                    loading="lazy">
                           <?php endif; ?>

                           <div class="ms-2">
                            <span class="small">
                                <i class="feather-user"></i>
                                <?php echo e($article->user->name); ?>

                            </span>
                               <br>
                               <span class="small">
                                <?php echo e($article->created_at->format("d M Y")); ?>

                            </span>
                           </div>
                       </div>

                       <a href="<?php echo e(route("detail", $article->id)); ?>" class="btn btn-outline-primary rounded-pill px-3">Read More</a>
                   </div>
               </div>
           </div>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

           <div class="mb-4 pb-4">
               <div class="py-5 my-5 text-center text-lg-start">
                   <p class="fw-bold text-primary">Dear Viewer</p>
                   <h1 class="fw-bold">
                       There is no article 😔 ...
                   </h1>
                   <p>Please go back to Home Page</p>
                   <a href="<?php echo e(route("index")); ?>" class="btn btn-primary rounded-pill px-3">
                       <i class="feather-home"></i>
                       Blog Home
                   </a>
               </div>
           </div>

       <?php endif; ?>
   </div>

   <div class="justify-content-center">
       <div class="d-block d-lg-none" id="pagination">
           <?php echo e($articles->onEachSide(1)->links()); ?>

       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("pagination-place"); ?>

    <div class="d-none d-lg-block" id="pagination">
        <?php echo e($articles->onEachSide(1)->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("blog.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Codes\my_projects\it_news\resources\views/welcome.blade.php ENDPATH**/ ?>