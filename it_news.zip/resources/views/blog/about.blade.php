@extends("blog.master")

@section("title") About @endsection

@section("content")
    <div class="p-2">
        <h1>This is About Page</h1>
    </div>
@endsection
